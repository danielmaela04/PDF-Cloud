$(document).ready(function () {
    setTimeout(() => {
        $("#loader").fadeToggle(250);
    }, 800);
  });