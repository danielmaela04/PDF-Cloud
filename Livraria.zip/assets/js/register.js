$('.custom-file-upload input[type="file"]').each(function () {
    var $fileUpload = $(this),
        $filelabel = $fileUpload.next('label'),
        $filelabelText = $filelabel.find('span'),
        filelabelDefault = $filelabelText.text();
    $fileUpload.on('change', function (event) {
        var name = $fileUpload.val().split('\\').pop(),
            tmppath = URL.createObjectURL(event.target.files[0]);
        if (name) {
            $filelabel
                .addClass('file-uploaded')
                .css('background-image', 'url(' + tmppath + ')');
            $filelabelText.text(name);
        } else {
            $filelabel.removeClass('file-uploaded');
            $filelabelText.text(filelabelDefault);
        }
    });
});

var MAX_SIZE = 1024 * 1024 * 5; // 5 MB
var VALID_TYPES = ['.pdf'];

function validateFile() {
	if (this.files && this.files.length) {
		var file = this.files[0];
		
		//console.log(file);
		var type = file.type;
		var size = file.size;
		var fileNameSplit = file.name.split('.');
		var extension = fileNameSplit[fileNameSplit.length - 1];
		
		//console.log(type);
		//console.log(extension);
		//console.log(size);
		
		if (size > MAX_SIZE) {
			$('#error-file-too-large').addClass('state-visible');
		} else {
			$('#error-file-too-large').removeClass('state-visible');
		}
		
		if (VALID_TYPES.indexOf(type) < 0) {
			$('#error-invalid-type').addClass('state-visible');
		} else {
			$('#error-invalid-type').removeClass('state-visible');
		}
	}
}

$(document).ready(function() {
	$('#fileuploadInput').on('change', validateFile);
});